This directory is for tracker extensions:

- CGI Actions
- Templating functions

See the customisation doc for more information.
