''' CGI interface modules '''
__docformat__ = 'restructuredtext'
