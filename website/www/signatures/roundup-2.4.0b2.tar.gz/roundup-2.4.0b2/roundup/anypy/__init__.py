"""
roundup.anypy - compatibility layer for any Python 2.3+
"""
VERSION = '.'.join(map(str,
                       (0,
                        3,
                        )))
