try:
    # Python 2.
    my_input = raw_input
except NameError:
    # Python 3+.
    my_input = input
