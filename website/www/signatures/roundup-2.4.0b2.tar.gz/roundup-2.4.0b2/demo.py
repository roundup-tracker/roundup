#!/usr/bin/env python3
import sys
import roundup

from roundup.demo import main

sys.exit(main())
