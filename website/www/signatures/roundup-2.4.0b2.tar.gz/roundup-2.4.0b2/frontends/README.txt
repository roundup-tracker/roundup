This directory contains alternate front-ends for Roundup.

roundup.cgi
   This is a cgi-bin script.

wsgi.py
   This is a wrapper to be used when running under wsgi.

ZRoundup
   This is a simple Zope frontend that installs as a regular Zope product.

See Roundup's doc/installation.txt for more info on installing these
frontends.
